import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Product Categories - Categorias de produtos (comidas, bebidas, aluguel de equipamentos)
 */
export const categories = mysqlTable("categories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  description: text("description"),
  color: varchar("color", { length: 7 }).default("#3B82F6"),
  icon: varchar("icon", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Category = typeof categories.$inferSelect;
export type InsertCategory = typeof categories.$inferInsert;

/**
 * Products - Produtos (comidas, bebidas, equipamentos de aluguel)
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  categoryId: int("categoryId").notNull().references(() => categories.id),
  name: varchar("name", { length: 150 }).notNull(),
  description: text("description"),
  price: int("price").notNull(), // Armazenar em centavos (ex: 1000 = R$ 10,00)
  ean: varchar("ean", { length: 20 }),
  photoUrl: text("photoUrl"),
  stock: int("stock").default(0),
  active: int("active").default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Locations - Localizações (7 quadras + 1 campo)
 */
export const locations = mysqlTable("locations", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 50 }).notNull(),
  type: mysqlEnum("type", ["quadra", "campo"]).notNull(),
  number: int("number"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Location = typeof locations.$inferSelect;
export type InsertLocation = typeof locations.$inferInsert;

/**
 * Comandas - Comandas abertas por localização
 */
export const comandas = mysqlTable("comandas", {
  id: int("id").autoincrement().primaryKey(),
  locationId: int("locationId").notNull().references(() => locations.id),
  customerName: varchar("customerName", { length: 150 }).notNull(),
  totalAmount: int("totalAmount").default(0), // Em centavos
  status: mysqlEnum("status", ["aberta", "fechada", "cancelada"]).default("aberta"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  closedAt: timestamp("closedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Comanda = typeof comandas.$inferSelect;
export type InsertComanda = typeof comandas.$inferInsert;

/**
 * Comanda Items - Itens de cada comanda
 */
export const comandaItems = mysqlTable("comanda_items", {
  id: int("id").autoincrement().primaryKey(),
  comandaId: int("comandaId").notNull().references(() => comandas.id),
  productId: int("productId").notNull().references(() => products.id),
  quantity: int("quantity").notNull(),
  unitPrice: int("unitPrice").notNull(), // Preço no momento da venda
  subtotal: int("subtotal").notNull(), // quantity * unitPrice
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ComandaItem = typeof comandaItems.$inferSelect;
export type InsertComandaItem = typeof comandaItems.$inferInsert;

/**
 * Sales - Vendas diretas (pagamento imediato)
 */
export const sales = mysqlTable("sales", {
  id: int("id").autoincrement().primaryKey(),
  totalAmount: int("totalAmount").notNull(), // Em centavos
  paymentMethod: mysqlEnum("paymentMethod", ["dinheiro", "cartao", "pix"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Sale = typeof sales.$inferSelect;
export type InsertSale = typeof sales.$inferInsert;

/**
 * Sale Items - Itens de cada venda direta
 */
export const saleItems = mysqlTable("sale_items", {
  id: int("id").autoincrement().primaryKey(),
  saleId: int("saleId").notNull().references(() => sales.id),
  productId: int("productId").notNull().references(() => products.id),
  quantity: int("quantity").notNull(),
  unitPrice: int("unitPrice").notNull(),
  subtotal: int("subtotal").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SaleItem = typeof saleItems.$inferSelect;
export type InsertSaleItem = typeof saleItems.$inferInsert;

/**
 * Stock Movements - Histórico de movimentações de estoque
 */
export const stockMovements = mysqlTable("stock_movements", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull().references(() => products.id),
  quantity: int("quantity").notNull(), // Positivo para entrada, negativo para saída
  type: mysqlEnum("type", ["entrada", "saida_venda", "saida_comanda", "ajuste"]).notNull(),
  reference: varchar("reference", { length: 100 }), // ID da venda ou comanda
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type StockMovement = typeof stockMovements.$inferSelect;
export type InsertStockMovement = typeof stockMovements.$inferInsert;