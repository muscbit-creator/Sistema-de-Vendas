import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { Calendar, ChevronDown, ChevronUp } from "lucide-react";

export default function History() {
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");
  const [expandedSale, setExpandedSale] = useState<number | null>(null);
  const [expandedComanda, setExpandedComanda] = useState<number | null>(null);

  // Queries
  const { data: historicalSales, isLoading: salesLoading } = trpc.history.sales.useQuery({
    startDate: startDate ? new Date(startDate) : undefined,
    endDate: endDate ? new Date(endDate) : undefined,
  });

  const { data: historicalComandas, isLoading: comandasLoading } = trpc.history.comandas.useQuery({
    startDate: startDate ? new Date(startDate) : undefined,
    endDate: endDate ? new Date(endDate) : undefined,
  });

  // Group sales by date
  const salesByDate = (historicalSales || []).reduce((acc: any, sale: any) => {
    const date = new Date(sale.createdAt).toLocaleDateString("pt-BR");
    if (!acc[date]) acc[date] = [];
    acc[date].push(sale);
    return acc;
  }, {});

  // Group comandas by date
  const comandasByDate = (historicalComandas || []).reduce((acc: any, comanda: any) => {
    const date = comanda.closedAt ? new Date(comanda.closedAt).toLocaleDateString("pt-BR") : "Sem data";
    if (!acc[date]) acc[date] = [];
    acc[date].push(comanda);
    return acc;
  }, {});

  // Calculate totals
  const totalSalesAmount = (historicalSales || []).reduce((sum, sale) => sum + (sale.totalAmount || 0), 0);
  const totalComandasAmount = (historicalComandas || []).reduce((sum, comanda) => sum + (comanda.totalAmount || 0), 0);

  return (
    <div className="space-y-6 p-4 md:p-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Histórico de Vendas</h1>
        <p className="text-gray-600 mt-2">Consulte vendas e comandas de dias anteriores</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base md:text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="startDate">Data Inicial</Label>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-400" />
                <Input
                  id="startDate"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="endDate">Data Final</Label>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-400" />
                <Input
                  id="endDate"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
          <Button
            onClick={() => {
              setStartDate("");
              setEndDate("");
            }}
            variant="outline"
            className="mt-4 w-full md:w-auto"
          >
            Limpar Filtros
          </Button>
        </CardContent>
      </Card>

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-gray-600">Total de Vendas Diretas</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl md:text-3xl font-bold text-blue-600">
              R$ {(totalSalesAmount / 100).toFixed(2)}
            </p>
            <p className="text-xs md:text-sm text-gray-500 mt-1">{(historicalSales || []).length} transações</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-gray-600">Total de Comandas Fechadas</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl md:text-3xl font-bold text-purple-600">
              R$ {(totalComandasAmount / 100).toFixed(2)}
            </p>
            <p className="text-xs md:text-sm text-gray-500 mt-1">{(historicalComandas || []).length} comandas</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-gray-600">Faturamento Total</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl md:text-3xl font-bold text-green-600">
              R$ {((totalSalesAmount + totalComandasAmount) / 100).toFixed(2)}
            </p>
            <p className="text-xs md:text-sm text-gray-500 mt-1">Todas as operações</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="sales" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="sales">Vendas Diretas</TabsTrigger>
          <TabsTrigger value="comandas">Comandas Fechadas</TabsTrigger>
        </TabsList>

        {/* Sales Tab */}
        <TabsContent value="sales" className="space-y-4">
          {salesLoading ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-500">Carregando...</p>
              </CardContent>
            </Card>
          ) : Object.keys(salesByDate).length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-500">Nenhuma venda encontrada no período</p>
              </CardContent>
            </Card>
          ) : (
            Object.entries(salesByDate).map(([date, sales]: [string, any]) => (
              <Card key={date}>
                <CardHeader>
                  <CardTitle className="text-base md:text-lg">{date}</CardTitle>
                  <CardDescription>
                    {sales.length} venda{sales.length !== 1 ? "s" : ""} - Total: R$ {(sales.reduce((sum: number, s: any) => sum + s.totalAmount, 0) / 100).toFixed(2)}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {sales.map((sale: any, index: number) => {
                      const isExpanded = expandedSale === index;
                      return (
                        <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                          <button
                            onClick={() => setExpandedSale(isExpanded ? null : index)}
                            className="w-full flex justify-between items-center p-3 bg-gray-50 hover:bg-gray-100 transition-colors"
                          >
                            <div className="text-left flex-1">
                              <p className="font-semibold text-sm">Venda #{index + 1}</p>
                              <p className="text-xs text-gray-600">{new Date(sale.createdAt).toLocaleTimeString("pt-BR")}</p>
                              <p className="text-xs text-gray-500 capitalize mt-1">Pagamento: {sale.paymentMethod}</p>
                            </div>
                            <div className="text-right mr-3">
                              <p className="font-bold text-green-600">R$ {(sale.totalAmount / 100).toFixed(2)}</p>
                              <p className="text-xs text-gray-500">{sale.items?.length || 0} itens</p>
                            </div>
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-gray-600" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-gray-600" />
                            )}
                          </button>

                          {isExpanded && sale.items && sale.items.length > 0 && (
                            <div className="p-3 bg-white border-t border-gray-200 space-y-2">
                              <p className="text-xs font-semibold text-gray-600 uppercase mb-2">Itens da Venda</p>
                              {sale.items.map((item: any, itemIndex: number) => (
                                <div key={itemIndex} className="flex justify-between items-center p-2 bg-blue-50 rounded border border-blue-100">
                                  <div className="flex-1">
                                    <p className="text-sm font-medium text-gray-900">{item.productName}</p>
                                    <p className="text-xs text-gray-600">{item.quantity}x R$ {(item.unitPrice / 100).toFixed(2)}</p>
                                  </div>
                                  <p className="text-sm font-bold text-blue-600">R$ {(item.subtotal / 100).toFixed(2)}</p>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* Comandas Tab */}
        <TabsContent value="comandas" className="space-y-4">
          {comandasLoading ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-500">Carregando...</p>
              </CardContent>
            </Card>
          ) : Object.keys(comandasByDate).length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-gray-500">Nenhuma comanda encontrada no período</p>
              </CardContent>
            </Card>
          ) : (
            Object.entries(comandasByDate).map(([date, comandas]: [string, any]) => (
              <Card key={date}>
                <CardHeader>
                  <CardTitle className="text-base md:text-lg">{date}</CardTitle>
                  <CardDescription>
                    {comandas.length} comanda{comandas.length !== 1 ? "s" : ""} - Total: R$ {(comandas.reduce((sum: number, c: any) => sum + (c.totalAmount || 0), 0) / 100).toFixed(2)}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {comandas.map((comanda: any, index: number) => {
                      const isExpanded = expandedComanda === index;
                      return (
                        <div key={index} className="border border-gray-200 rounded-lg overflow-hidden">
                          <button
                            onClick={() => setExpandedComanda(isExpanded ? null : index)}
                            className="w-full flex justify-between items-center p-3 bg-gray-50 hover:bg-gray-100 transition-colors"
                          >
                            <div className="text-left flex-1">
                              <p className="font-semibold text-sm">{comanda.customerName}</p>
                              <p className="text-xs text-gray-600">Fechada em {new Date(comanda.closedAt).toLocaleTimeString("pt-BR")}</p>
                            </div>
                            <div className="text-right mr-3">
                              <p className="font-bold text-purple-600">R$ {(comanda.totalAmount / 100).toFixed(2)}</p>
                              <p className="text-xs text-gray-500">{comanda.items?.length || 0} itens</p>
                            </div>
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4 text-gray-600" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-gray-600" />
                            )}
                          </button>

                          {isExpanded && comanda.items && comanda.items.length > 0 && (
                            <div className="p-3 bg-white border-t border-gray-200 space-y-2">
                              <p className="text-xs font-semibold text-gray-600 uppercase mb-2">Itens da Comanda</p>
                              {comanda.items.map((item: any, itemIndex: number) => (
                                <div key={itemIndex} className="flex justify-between items-center p-2 bg-purple-50 rounded border border-purple-100">
                                  <div className="flex-1">
                                    <p className="text-sm font-medium text-gray-900">{item.productName}</p>
                                    <p className="text-xs text-gray-600">{item.quantity}x R$ {(item.unitPrice / 100).toFixed(2)}</p>
                                  </div>
                                  <p className="text-sm font-bold text-purple-600">R$ {(item.subtotal / 100).toFixed(2)}</p>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
