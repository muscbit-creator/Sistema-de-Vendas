import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Minus, ShoppingCart, Trash2 } from "lucide-react";

interface CartItem {
  productId: number;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

export default function Sales() {
  const [activeTab, setActiveTab] = useState<"direct" | "comanda">("direct");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<"dinheiro" | "cartao" | "pix">("dinheiro");
  const [selectedLocation, setSelectedLocation] = useState<string>("");
  const [customerName, setCustomerName] = useState("");

  // Queries
  const { data: products } = trpc.products.list.useQuery();
  const { data: locations } = trpc.locations.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();

  // Mutations
  const createSale = trpc.sales.create.useMutation({
    onSuccess: (data) => {
      toast.success(`Venda realizada! ID: ${data.id}`);
      setCart([]);
      setPaymentMethod("dinheiro");
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const createComanda = trpc.comandas.create.useMutation({
    onSuccess: () => {
      toast.success("Comanda criada com sucesso!");
      setCustomerName("");
      setSelectedLocation("");
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const addToCart = (product: any) => {
    const existingItem = cart.find((item) => item.productId === product.id);
    if (existingItem) {
      setCart(
        cart.map((item) =>
          item.productId === product.id
            ? {
                ...item,
                quantity: item.quantity + 1,
                subtotal: (item.quantity + 1) * item.unitPrice,
              }
            : item
        )
      );
    } else {
      setCart([
        ...cart,
        {
          productId: product.id,
          productName: product.name,
          quantity: 1,
          unitPrice: product.price,
          subtotal: product.price,
        },
      ]);
    }
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      setCart(
        cart.map((item) =>
          item.productId === productId
            ? {
                ...item,
                quantity,
                subtotal: quantity * item.unitPrice,
              }
            : item
        )
      );
    }
  };

  const removeFromCart = (productId: number) => {
    setCart(cart.filter((item) => item.productId !== productId));
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.subtotal, 0);

  const handleCompleteSale = () => {
    if (cart.length === 0) {
      toast.error("Adicione produtos ao carrinho");
      return;
    }
    createSale.mutate({
      items: cart.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
      })),
      paymentMethod,
    });
  };

  const handleCreateComanda = () => {
    if (!selectedLocation || !customerName) {
      toast.error("Preencha todos os campos");
      return;
    }
    createComanda.mutate({
      locationId: parseInt(selectedLocation),
      customerName,
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Sistema de Vendas</h1>
        <p className="text-gray-600 mt-2">Realize vendas diretas ou abra comandas por localização</p>
      </div>

      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "direct" | "comanda")}>
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="direct">Venda Direta</TabsTrigger>
          <TabsTrigger value="comanda">Abrir Comanda</TabsTrigger>
        </TabsList>

        <TabsContent value="direct" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Products Section */}
            <div className="lg:col-span-2 space-y-4">
              {categories?.map((category) => (
                <div key={category.id}>
                  <h3 className="text-lg font-bold mb-3">{category.name}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {products
                      ?.filter((p) => p.categoryId === category.id)
                      .map((product) => (
                        <Card
                          key={product.id}
                          className="cursor-pointer hover:shadow-lg transition-shadow"
                          onClick={() => addToCart(product)}
                        >
                          <CardContent className="p-3">
                            {product.photoUrl && (
                              <img
                                src={product.photoUrl}
                                alt={product.name}
                                className="w-full h-20 object-cover rounded mb-2"
                              />
                            )}
                            <p className="font-semibold text-sm truncate">{product.name}</p>
                            <p className="text-green-600 font-bold">R$ {(product.price / 100).toFixed(2)}</p>
                            <Button size="sm" className="w-full mt-2 bg-blue-600 hover:bg-blue-700">
                              <Plus className="w-4 h-4 mr-1" />
                              Adicionar
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Cart Section */}
            <div className="space-y-4">
              <Card className="sticky top-4">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Carrinho
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {cart.length === 0 ? (
                    <p className="text-center text-gray-500">Nenhum produto adicionado</p>
                  ) : (
                    <>
                      <div className="space-y-3 max-h-64 overflow-y-auto">
                        {cart.map((item) => (
                          <div key={item.productId} className="border rounded p-2">
                            <div className="flex justify-between items-start mb-2">
                              <p className="font-semibold text-sm">{item.productName}</p>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => removeFromCart(item.productId)}
                              >
                                <Trash2 className="w-4 h-4 text-red-600" />
                              </Button>
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                >
                                  <Minus className="w-3 h-3" />
                                </Button>
                                <span className="w-8 text-center font-bold">{item.quantity}</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                                >
                                  <Plus className="w-3 h-3" />
                                </Button>
                              </div>
                              <p className="font-bold text-sm">R$ {(item.subtotal / 100).toFixed(2)}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="border-t pt-3 space-y-3">
                        <div className="flex justify-between font-bold text-lg">
                          <span>Total:</span>
                          <span className="text-green-600">R$ {(totalAmount / 100).toFixed(2)}</span>
                        </div>

                        <div>
                          <Label htmlFor="paymentMethod">Forma de Pagamento</Label>
                          <Select value={paymentMethod} onValueChange={(value) => setPaymentMethod(value as any)}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="dinheiro">Dinheiro</SelectItem>
                              <SelectItem value="cartao">Cartão</SelectItem>
                              <SelectItem value="pix">PIX</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <Button
                          onClick={handleCompleteSale}
                          disabled={createSale.isPending}
                          className="w-full bg-green-600 hover:bg-green-700"
                        >
                          {createSale.isPending ? "Processando..." : "Finalizar Venda"}
                        </Button>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="comanda" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Abrir Nova Comanda</CardTitle>
              <CardDescription>Crie uma comanda para um cliente em uma localização específica</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="customerName">Nome do Cliente</Label>
                  <Input
                    id="customerName"
                    placeholder="Ex: José da Quadra 4"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="location">Localização</Label>
                  <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma localização" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations?.map((loc) => (
                        <SelectItem key={loc.id} value={loc.id.toString()}>
                          {loc.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button
                onClick={handleCreateComanda}
                disabled={createComanda.isPending}
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                {createComanda.isPending ? "Criando..." : "Criar Comanda"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
