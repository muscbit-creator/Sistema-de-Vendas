import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Edit2, Trash2, Image as ImageIcon, Loader2 } from "lucide-react";

export default function Products() {
  const [openProductDialog, setOpenProductDialog] = useState(false);
  const [openCategoryDialog, setOpenCategoryDialog] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [photoPreview, setPhotoPreview] = useState<string>("");
  const [isUploading, setIsUploading] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [newCategoryDesc, setNewCategoryDesc] = useState("");
  const [newCategoryColor, setNewCategoryColor] = useState("#3B82F6");

  // Queries
  const { data: categories, refetch: refetchCategories } = trpc.categories.list.useQuery();
  const { data: products, refetch: refetchProducts } = trpc.products.list.useQuery();

  // Mutations
  const createCategory = trpc.categories.create.useMutation({
    onSuccess: () => {
      toast.success("Categoria criada com sucesso!");
      refetchCategories();
      setOpenCategoryDialog(false);
      setNewCategoryName("");
      setNewCategoryDesc("");
      setNewCategoryColor("#3B82F6");
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const createProduct = trpc.products.create.useMutation({
    onSuccess: () => {
      toast.success("Produto criado com sucesso!");
      refetchProducts();
      setOpenProductDialog(false);
      setPhotoPreview("");
      setSelectedCategory("");
      setEditingProduct(null);
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const updateProduct = trpc.products.update.useMutation({
    onSuccess: () => {
      toast.success("Produto atualizado com sucesso!");
      refetchProducts();
      setOpenProductDialog(false);
      setPhotoPreview("");
      setSelectedCategory("");
      setEditingProduct(null);
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const deleteProduct = trpc.products.delete.useMutation({
    onSuccess: () => {
      toast.success("Produto deletado com sucesso!");
      refetchProducts();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleCreateCategory = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    createCategory.mutate({
      name: newCategoryName,
      description: newCategoryDesc,
      color: newCategoryColor,
    });
  };

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Show preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);

      // Upload to server
      setIsUploading(true);
      try {
        const buffer = await file.arrayBuffer();
        // Note: In a real scenario, you'd call an upload endpoint
        // For now, we'll store the base64 as photoUrl
        toast.success("Foto selecionada com sucesso!");
      } catch (error) {
        toast.error("Erro ao fazer upload da foto");
      } finally {
        setIsUploading(false);
      }
    }
  };

  const handleCreateProduct = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedCategory) {
      toast.error("Selecione uma categoria");
      return;
    }
    const formData = new FormData(e.currentTarget);
    const productData = {
      categoryId: parseInt(selectedCategory),
      name: formData.get("productName") as string,
      description: formData.get("productDescription") as string,
      price: Math.round(parseFloat(formData.get("productPrice") as string) * 100),
      ean: formData.get("productEan") as string,
      stock: parseInt(formData.get("productStock") as string) || 0,
      photoUrl: photoPreview,
    };

    if (editingProduct) {
      updateProduct.mutate({ id: editingProduct.id, ...productData });
    } else {
      createProduct.mutate(productData);
    }
  };

  const handleEditProduct = (product: any) => {
    setEditingProduct(product);
    setSelectedCategory(product.categoryId.toString());
    setPhotoPreview(product.photoUrl || "");
    setOpenProductDialog(true);
  };

  return (
    <div className="space-y-8 p-4 md:p-6">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Gestão de Produtos</h1>
          <p className="text-gray-600 mt-2">Gerencie categorias e produtos do seu complexo</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <Dialog open={openCategoryDialog} onOpenChange={setOpenCategoryDialog}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto">
                <Plus className="w-4 h-4 mr-2" />
                Nova Categoria
              </Button>
            </DialogTrigger>
            <DialogContent className="w-[95vw] md:w-full">
              <DialogHeader>
                <DialogTitle>Criar Nova Categoria</DialogTitle>
                <DialogDescription>Adicione uma nova categoria de produtos</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreateCategory} className="space-y-4">
                <div>
                  <Label htmlFor="categoryName">Nome da Categoria</Label>
                  <Input
                    id="categoryName"
                    placeholder="Ex: Bebidas, Comidas, Aluguel"
                    value={newCategoryName}
                    onChange={(e) => setNewCategoryName(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="categoryDescription">Descrição</Label>
                  <Textarea
                    id="categoryDescription"
                    placeholder="Descrição da categoria"
                    value={newCategoryDesc}
                    onChange={(e) => setNewCategoryDesc(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="categoryColor">Cor</Label>
                  <Input
                    id="categoryColor"
                    type="color"
                    value={newCategoryColor}
                    onChange={(e) => setNewCategoryColor(e.target.value)}
                  />
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                  Criar Categoria
                </Button>
              </form>
            </DialogContent>
          </Dialog>

          <Dialog open={openProductDialog} onOpenChange={setOpenProductDialog}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700 w-full sm:w-auto">
                <Plus className="w-4 h-4 mr-2" />
                Novo Produto
              </Button>
            </DialogTrigger>
            <DialogContent className="w-[95vw] md:max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingProduct ? "Editar Produto" : "Cadastrar Novo Produto"}</DialogTitle>
                <DialogDescription>
                  {editingProduct ? "Atualize os dados do produto" : "Adicione um novo produto ao seu catálogo"}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreateProduct} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="productName">Nome do Produto</Label>
                    <Input
                      id="productName"
                      name="productName"
                      placeholder="Ex: Água 500ml"
                      defaultValue={editingProduct?.name || ""}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="productCategory">Categoria</Label>
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories?.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id.toString()}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="productDescription">Descrição</Label>
                  <Textarea
                    id="productDescription"
                    name="productDescription"
                    placeholder="Descrição do produto"
                    defaultValue={editingProduct?.description || ""}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="productPrice">Preço (R$)</Label>
                    <Input
                      id="productPrice"
                      name="productPrice"
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      defaultValue={editingProduct ? (editingProduct.price / 100).toFixed(2) : ""}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="productEan">Código EAN</Label>
                    <Input
                      id="productEan"
                      name="productEan"
                      placeholder="Opcional"
                      defaultValue={editingProduct?.ean || ""}
                    />
                  </div>
                  <div>
                    <Label htmlFor="productStock">Estoque</Label>
                    <Input
                      id="productStock"
                      name="productStock"
                      type="number"
                      placeholder="0"
                      defaultValue={editingProduct?.stock || ""}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="productPhoto">Foto do Produto</Label>
                  <div className="border-2 border-dashed rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50">
                    <input
                      id="productPhoto"
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoSelect}
                      className="hidden"
                      disabled={isUploading}
                    />
                    <label htmlFor="productPhoto" className="cursor-pointer block">
                      {photoPreview ? (
                        <div className="space-y-2">
                          <img src={photoPreview} alt="Preview" className="h-32 mx-auto rounded" />
                          <p className="text-sm text-gray-600">Clique para mudar</p>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {isUploading ? (
                            <Loader2 className="w-8 h-8 mx-auto text-gray-400 animate-spin" />
                          ) : (
                            <ImageIcon className="w-8 h-8 mx-auto text-gray-400" />
                          )}
                          <p className="text-sm text-gray-600">Clique para adicionar foto</p>
                        </div>
                      )}
                    </label>
                  </div>
                </div>

                <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                  {editingProduct ? "Atualizar Produto" : "Cadastrar Produto"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Categories */}
      <div>
        <h2 className="text-lg md:text-xl font-bold mb-4">Categorias</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
          {categories?.map((category) => (
            <Card key={category.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div
                  className="w-12 h-12 rounded-lg mb-2"
                  style={{ backgroundColor: category.color || "#3B82F6" }}
                ></div>
                <CardTitle className="text-sm md:text-base">{category.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs md:text-sm text-gray-600 line-clamp-2">{category.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Products */}
      <div>
        <h2 className="text-lg md:text-xl font-bold mb-4">Produtos</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
          {products?.map((product) => (
            <Card key={product.id} className="hover:shadow-lg transition-shadow flex flex-col">
              <CardHeader className="pb-3">
                {product.photoUrl && (
                  <img
                    src={product.photoUrl}
                    alt={product.name}
                    className="w-full h-32 md:h-40 object-cover rounded-lg mb-2"
                  />
                )}
                <CardTitle className="text-sm md:text-base line-clamp-2">{product.name}</CardTitle>
                <CardDescription className="text-xs line-clamp-1">{product.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 flex-1 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs md:text-sm text-gray-600">Preço:</span>
                    <span className="font-bold text-green-600 text-sm md:text-base">R$ {(product.price / 100).toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs md:text-sm text-gray-600">Estoque:</span>
                    <span className="font-bold text-sm">{product.stock}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 text-xs md:text-sm"
                    onClick={() => handleEditProduct(product)}
                  >
                    <Edit2 className="w-3 h-3 md:w-4 md:h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 text-red-600 text-xs md:text-sm"
                    onClick={() => deleteProduct.mutate({ id: product.id })}
                  >
                    <Trash2 className="w-3 h-3 md:w-4 md:h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
