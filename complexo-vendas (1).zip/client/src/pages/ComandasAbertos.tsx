import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { X, Check, Eye } from "lucide-react";

export default function ComandasAbertos() {
  const [selectedComanda, setSelectedComanda] = useState<any>(null);
  const [openDetailsDialog, setOpenDetailsDialog] = useState(false);

  // Queries
  const { data: locations } = trpc.locations.list.useQuery();
  const { data: comandas, refetch: refetchComandas } = trpc.comandas.list.useQuery();

  // Mutations
  const closeComanda = trpc.comandas.close.useMutation({
    onSuccess: () => {
      toast.success("Comanda fechada com sucesso!");
      refetchComandas();
      setOpenDetailsDialog(false);
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const removeItem = trpc.comandas.removeItem.useMutation({
    onSuccess: () => {
      toast.success("Item removido!");
      refetchComandas();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleViewDetails = (comanda: any) => {
    setSelectedComanda(comanda);
    setOpenDetailsDialog(true);
  };

  const handleCloseComanda = () => {
    if (!selectedComanda) return;
    closeComanda.mutate({ comandaId: selectedComanda.id });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Comandas Abertas</h1>
        <p className="text-gray-600 mt-2">Visualize e gerencie todas as comandas abertas por localização</p>
      </div>

      <Tabs defaultValue={locations?.[0]?.id.toString()} className="w-full">
        <TabsList className="grid w-full gap-2" style={{ gridTemplateColumns: `repeat(auto-fit, minmax(120px, 1fr))` }}>
          {locations?.map((location) => (
            <TabsTrigger key={location.id} value={location.id.toString()}>
              {location.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {locations?.map((location) => (
          <TabsContent key={location.id} value={location.id.toString()} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {(comandas || [])
                .filter((c) => c.locationId === location.id && c.status === "aberta")
                .map((comanda) => (
                  <Card key={comanda.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <CardTitle className="text-lg">{comanda.customerName}</CardTitle>
                      <CardDescription>
                        Aberta em {new Date(comanda.createdAt).toLocaleTimeString("pt-BR")}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="bg-gray-50 p-3 rounded-lg">
                        <p className="text-sm text-gray-600">Total</p>
                        <p className="text-2xl font-bold text-green-600">
                          R$ {((comanda.totalAmount || 0) / 100).toFixed(2)}
                        </p>
                      </div>

                      <div className="flex gap-2">
                        <Dialog open={openDetailsDialog && selectedComanda?.id === comanda.id} onOpenChange={setOpenDetailsDialog}>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              className="flex-1"
                              onClick={() => handleViewDetails(comanda)}
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              Detalhes
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>Detalhes da Comanda</DialogTitle>
                              <DialogDescription>
                                {selectedComanda?.customerName} - {locations?.find((l) => l.id === selectedComanda?.locationId)?.name}
                              </DialogDescription>
                            </DialogHeader>

                            {selectedComanda && (
                              <div className="space-y-4">
                                <div className="space-y-2">
                                  <h3 className="font-bold">Itens</h3>
                                  <div className="max-h-64 overflow-y-auto space-y-2">
                                    {(selectedComanda?.items || []).map((item: any) => (
                                      <div key={item.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                                        <div>
                                          <p className="font-semibold">{item.productId}</p>
                                          <p className="text-sm text-gray-600">
                                            {item.quantity}x R$ {(item.unitPrice / 100).toFixed(2)}
                                          </p>
                                        </div>
                                        <div className="flex items-center gap-2">
                                          <p className="font-bold">R$ {(item.subtotal / 100).toFixed(2)}</p>
                                          <Button
                                            size="sm"
                                            variant="ghost"
                                            onClick={() => removeItem.mutate({ itemId: item.id })}
                                          >
                                            <X className="w-4 h-4 text-red-600" />
                                          </Button>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                <div className="border-t pt-3">
                                  <div className="flex justify-between font-bold text-lg mb-4">
                                    <span>Total:</span>
                                    <span className="text-green-600">
                                      R$ {((selectedComanda.totalAmount || 0) / 100).toFixed(2)}
                                    </span>
                                  </div>

                                  <Button
                                    onClick={handleCloseComanda}
                                    disabled={closeComanda.isPending}
                                    className="w-full bg-green-600 hover:bg-green-700"
                                  >
                                    <Check className="w-4 h-4 mr-2" />
                                    {closeComanda.isPending ? "Fechando..." : "Fechar Comanda"}
                                  </Button>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>

                        <Button
                          onClick={() => {
                            handleViewDetails(comanda);
                            setTimeout(() => handleCloseComanda(), 100);
                          }}
                          className="flex-1 bg-green-600 hover:bg-green-700"
                        >
                          <Check className="w-4 h-4 mr-2" />
                          Fechar
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}

              {!(comandas || []).some((c) => c.locationId === location.id && c.status === "aberta") && (
                <Card className="col-span-full">
                  <CardContent className="p-8 text-center">
                    <p className="text-gray-500">Nenhuma comanda aberta nesta localização</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Resumo de Comandas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Total de Comandas Abertas</p>
              <p className="text-3xl font-bold text-blue-600">
                {comandas?.filter((c) => c.status === "aberta").length || 0}
              </p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Faturamento em Comandas</p>
              <p className="text-3xl font-bold text-green-600">
                R$ {((comandas || []).filter((c) => c.status === "aberta").reduce((sum, c) => sum + (c.totalAmount || 0), 0) / 100).toFixed(2)}
              </p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <p className="text-sm text-gray-600">Ticket Médio</p>
              <p className="text-3xl font-bold text-purple-600">
                R$ {
                  (comandas || []).filter((c) => c.status === "aberta").length
                    ? (
                        (comandas || [])
                          .filter((c) => c.status === "aberta")
                          .reduce((sum, c) => sum + (c.totalAmount || 0), 0) /
                        (comandas || []).filter((c) => c.status === "aberta").length /
                        100
                      ).toFixed(2)
                    : "0.00"
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
