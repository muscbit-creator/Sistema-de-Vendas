import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Minus, Trash2, ShoppingCart } from "lucide-react";

interface CartItem {
  productId: number;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  photoUrl?: string;
}

export default function VendaDireta() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState("dinheiro");

  // Queries
  const { data: products } = trpc.products.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();
  const { data: sales, refetch: refetchSales } = trpc.sales.today.useQuery();

  // Mutations
  const createSale = trpc.sales.create.useMutation({
    onSuccess: () => {
      toast.success("Venda registrada com sucesso!");
      setCart([]);
      setPaymentMethod("dinheiro");
      refetchSales();
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const addToCart = (product: any) => {
    const existingItem = cart.find((item) => item.productId === product.id);
    if (existingItem) {
      setCart(
        cart.map((item) =>
          item.productId === product.id
            ? {
                ...item,
                quantity: item.quantity + 1,
                subtotal: (item.quantity + 1) * item.unitPrice,
              }
            : item
        )
      );
    } else {
      setCart([
        ...cart,
        {
          productId: product.id,
          productName: product.name,
          quantity: 1,
          unitPrice: product.price,
          subtotal: product.price,
          photoUrl: product.photoUrl,
        },
      ]);
    }
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
    } else {
      setCart(
        cart.map((item) =>
          item.productId === productId
            ? {
                ...item,
                quantity,
                subtotal: quantity * item.unitPrice,
              }
            : item
        )
      );
    }
  };

  const removeFromCart = (productId: number) => {
    setCart(cart.filter((item) => item.productId !== productId));
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.subtotal, 0);

  const handleCompleteSale = () => {
    if (cart.length === 0) {
      toast.error("Adicione produtos ao carrinho");
      return;
    }

    createSale.mutate({
      items: cart.map((item) => ({
        productId: item.productId,
        quantity: item.quantity,
      })),
      paymentMethod: paymentMethod as "dinheiro" | "cartao" | "pix",
    });
  };

  return (
    <div className="space-y-6 md:space-y-8 p-4 md:p-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Venda Direta</h1>
        <p className="text-gray-600 mt-2 text-sm md:text-base">Registre vendas rápidas de produtos</p>
      </div>

      <Tabs defaultValue="venda" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="venda">Nova Venda</TabsTrigger>
          <TabsTrigger value="historico">Histórico</TabsTrigger>
        </TabsList>

        {/* Nova Venda Tab */}
        <TabsContent value="venda" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Products Section */}
            <div className="lg:col-span-2 space-y-3 md:space-y-4">
              {categories?.map((category) => (
                <div key={category.id}>
                  <h3 className="text-lg font-bold mb-3">{category.name}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 md:gap-3">
                    {products
                      ?.filter((p) => p.categoryId === category.id)
                      .map((product) => (
                        <Card
                          key={product.id}
                          className="cursor-pointer hover:shadow-lg transition-shadow"
                          onClick={() => addToCart(product)}
                        >
                          <CardContent className="p-2 md:p-3">
                            {product.photoUrl && (
                              <img
                                src={product.photoUrl}
                                alt={product.name}
                                className="w-full h-16 md:h-24 object-cover rounded mb-1 md:mb-2"
                              />
                            )}
                            <p className="font-semibold text-xs md:text-sm truncate">{product.name}</p>
                            <p className="text-green-600 font-bold text-xs md:text-sm">R$ {(product.price / 100).toFixed(2)}</p>
                            <Button size="sm" className="w-full mt-1 md:mt-2 bg-blue-600 hover:bg-blue-700 text-xs md:text-sm">
                              <Plus className="w-3 h-3 md:w-4 md:h-4 mr-1" />
                              Adicionar
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Cart Section */}
            <div className="space-y-3 md:space-y-4">
              <Card className="sticky top-4 md:top-6">
                <CardHeader>
                  <CardTitle>Carrinho</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {cart.length === 0 ? (
                    <p className="text-center text-gray-500">Nenhum produto adicionado</p>
                  ) : (
                    <>
                      <div className="space-y-2 md:space-y-3 max-h-64 overflow-y-auto">
                        {cart.map((item) => (
                          <div key={item.productId} className="border rounded p-2">
                            {item.photoUrl && (
                              <img
                                src={item.photoUrl}
                                alt={item.productName}
                                className="w-full h-12 md:h-16 object-cover rounded mb-1 md:mb-2"
                              />
                            )}
                            <div className="flex justify-between items-start mb-1 md:mb-2">
                              <p className="font-semibold text-xs md:text-sm truncate">{item.productName}</p>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="p-0"
                                onClick={() => removeFromCart(item.productId)}
                              >
                                <Trash2 className="w-3 h-3 md:w-4 md:h-4 text-red-600" />
                              </Button>
                            </div>
                            <div className="flex items-center justify-between gap-1">
                              <div className="flex items-center gap-1">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="p-0 w-6 h-6 md:w-8 md:h-8"
                                  onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                >
                                  <Minus className="w-2 h-2 md:w-3 md:h-3" />
                                </Button>
                                <span className="w-6 text-center font-bold text-xs md:text-sm">{item.quantity}</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="p-0 w-6 h-6 md:w-8 md:h-8"
                                  onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                                >
                                  <Plus className="w-2 h-2 md:w-3 md:h-3" />
                                </Button>
                              </div>
                              <p className="font-bold text-xs md:text-sm">R$ {(item.subtotal / 100).toFixed(2)}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="border-t pt-3 space-y-3">
                        <div className="flex justify-between font-bold text-lg">
                          <span>Total:</span>
                          <span className="text-green-600">R$ {(totalAmount / 100).toFixed(2)}</span>
                        </div>

                        <div>
                          <Label htmlFor="payment">Forma de Pagamento</Label>
                          <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="dinheiro">Dinheiro</SelectItem>
                              <SelectItem value="cartao">Cartão</SelectItem>
                              <SelectItem value="pix">PIX</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <Button
                          onClick={handleCompleteSale}
                          disabled={createSale.isPending || cart.length === 0}
                          className="w-full bg-green-600 hover:bg-green-700"
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          {createSale.isPending ? "Processando..." : "Confirmar Venda"}
                        </Button>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Histórico Tab */}
        <TabsContent value="historico" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Vendas</CardTitle>
              <CardDescription>Vendas diretas realizadas hoje</CardDescription>
            </CardHeader>
            <CardContent>
              {!sales || sales.length === 0 ? (
                <p className="text-center text-gray-500 py-8">Nenhuma venda registrada ainda</p>
              ) : (
                <div className="space-y-3">
                  {sales.map((sale, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <div>
                        <p className="font-semibold">Venda #{index + 1}</p>
                        <p className="text-sm text-gray-600">{new Date(sale.createdAt).toLocaleTimeString("pt-BR")}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600">R$ {((sale.totalAmount || 0) / 100).toFixed(2)}</p>
                        <p className="text-xs text-gray-500 capitalize">{sale.paymentMethod}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
