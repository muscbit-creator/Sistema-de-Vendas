import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [openNewComanda, setOpenNewComanda] = useState(false);
  const [newComandaData, setNewComandaData] = useState({ locationId: "", customerName: "" });

  // Queries
  const { data: dashboardData, isLoading } = trpc.dashboard.today.useQuery();
  const { data: locations } = trpc.locations.list.useQuery();
  const { data: comandas } = trpc.comandas.list.useQuery();

  // Mutations
  const createComanda = trpc.comandas.create.useMutation({
    onSuccess: () => {
      toast.success("Comanda aberta com sucesso!");
      setOpenNewComanda(false);
      setNewComandaData({ locationId: "", customerName: "" });
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleCreateComanda = () => {
    if (!newComandaData.locationId || !newComandaData.customerName) {
      toast.error("Preencha todos os campos");
      return;
    }
    createComanda.mutate({
      locationId: parseInt(newComandaData.locationId),
      customerName: newComandaData.customerName,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Prepare data for charts
  const chartData = [
    { name: "Vendas Diretas", value: dashboardData?.sales || 0, fill: "#3b82f6" },
    { name: "Comandas", value: dashboardData?.comandas || 0, fill: "#a855f7" },
  ];

  const openComandas = (comandas || []).filter((c) => c.status === "aberta");

  return (
    <div className="space-y-6 md:space-y-8 p-4 md:p-6">
      {/* Header with Action Buttons */}
      <div className="flex flex-col md:flex-row justify-between items-start gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Bem-vindo, {user?.name}!</h1>
          <p className="text-gray-600 mt-2 text-sm md:text-base">Resumo do dia - {new Date().toLocaleDateString("pt-BR")}</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <Button
            onClick={() => setLocation("/vendas")}
            className="bg-blue-600 hover:bg-blue-700 text-white w-full sm:w-auto"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nova Venda
          </Button>
          <Dialog open={openNewComanda} onOpenChange={setOpenNewComanda}>
            <DialogTrigger asChild>
              <Button className="bg-purple-600 hover:bg-purple-700 text-white w-full sm:w-auto">
                <Plus className="w-4 h-4 mr-2" />
                Abrir Comanda
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Abrir Nova Comanda</DialogTitle>
                <DialogDescription>Crie uma nova comanda para uma localização</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="location">Localização</Label>
                  <Select value={newComandaData.locationId} onValueChange={(value) => setNewComandaData({ ...newComandaData, locationId: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma localização" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations?.map((loc) => (
                        <SelectItem key={loc.id} value={loc.id.toString()}>
                          {loc.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="customer">Nome do Cliente</Label>
                  <Input
                    id="customer"
                    placeholder="Ex: José da Quadra 1"
                    value={newComandaData.customerName}
                    onChange={(e) => setNewComandaData({ ...newComandaData, customerName: e.target.value })}
                  />
                </div>
                <Button
                  onClick={handleCreateComanda}
                  disabled={createComanda.isPending}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {createComanda.isPending ? "Abrindo..." : "Abrir Comanda"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Vendas Diretas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{dashboardData?.sales || 0}</div>
            <p className="text-xs text-gray-500 mt-1">Atualizado agora</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Comandas Abertas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{dashboardData?.comandas || 0}</div>
            <p className="text-xs text-gray-500 mt-1">Atualizado agora</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Faturamento</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">R$ {((dashboardData?.totalRevenue || 0) / 100).toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-1">Atualizado agora</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts and Comandas */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
        {/* Distribution Chart */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Distribuição de Vendas</CardTitle>
            <CardDescription>Vendas diretas vs Comandas</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Open Comandas Summary */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base md:text-lg">Comandas Abertas</CardTitle>
            <CardDescription className="text-xs md:text-sm">Resumo de todas as comandas em aberto</CardDescription>
          </CardHeader>
          <CardContent>
            {openComandas.length === 0 ? (
              <p className="text-center text-gray-500 py-4 md:py-8 text-sm">Nenhuma comanda aberta no momento</p>
            ) : (
              <div className="space-y-2 md:space-y-3 max-h-96 overflow-y-auto">
                {openComandas.map((comanda) => {
                  const location = locations?.find((l) => l.id === comanda.locationId);
                  return (
                    <div key={comanda.id} className="flex justify-between items-center p-2 md:p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-xs md:text-sm truncate">{comanda.customerName}</p>
                        <p className="text-xs text-gray-500 truncate">{location?.name}</p>
                      </div>
                      <div className="text-right ml-2">
                        <p className="font-bold text-green-600 text-sm md:text-base">R$ {((comanda.totalAmount || 0) / 100).toFixed(2)}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Atividades Recentes</CardTitle>
          <CardDescription>Últimas transações do dia</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm text-gray-500">
            <p>Nenhuma atividade registrada ainda</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
