import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Plus, Eye, Check, Trash2, X, Minus } from "lucide-react";

export default function Comandas() {
  const [openNewComanda, setOpenNewComanda] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<string>("");
  const [customerName, setCustomerName] = useState("");
  const [selectedComanda, setSelectedComanda] = useState<any>(null);
  const [openDetailsDialog, setOpenDetailsDialog] = useState(false);
  const [cart, setCart] = useState<any[]>([]);

  // Queries
  const { data: locations } = trpc.locations.list.useQuery();
  const { data: comandas, refetch: refetchComandas } = trpc.comandas.list.useQuery();
  const { data: products } = trpc.products.list.useQuery();
  const { data: categories } = trpc.categories.list.useQuery();

  // Mutations
  const createComanda = trpc.comandas.create.useMutation({
    onSuccess: () => {
      toast.success("Comanda criada com sucesso!");
      refetchComandas();
      setOpenNewComanda(false);
      setSelectedLocation("");
      setCustomerName("");
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const addItemToComanda = trpc.comandas.addItem.useMutation({
    onSuccess: () => {
      toast.success("Itens adicionados com sucesso!");
      refetchComandas();
      setCart([]);
      setOpenDetailsDialog(false);
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const removeItemFromComanda = trpc.comandas.removeItem.useMutation({
    onSuccess: () => {
      toast.success("Item removido com sucesso!");
      refetchComandas();
      setSelectedComanda(null);
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const closeComanda = trpc.comandas.close.useMutation({
    onSuccess: () => {
      toast.success("Comanda fechada com sucesso!");
      refetchComandas();
      setOpenDetailsDialog(false);
      setSelectedComanda(null);
    },
    onError: (error) => {
      toast.error(`Erro: ${error.message}`);
    },
  });

  const handleCreateComanda = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedLocation) {
      toast.error("Selecione uma localização");
      return;
    }
    createComanda.mutate({
      locationId: parseInt(selectedLocation),
      customerName,
    });
  };

  const handleViewDetails = (comanda: any) => {
    setSelectedComanda(comanda);
    setCart([]);
    setOpenDetailsDialog(true);
  };

  const addToCart = (product: any) => {
    const existing = cart.find((item) => item.productId === product.id);
    if (existing) {
      setCart(cart.map((item) => (item.productId === product.id ? { ...item, quantity: item.quantity + 1, subtotal: (item.quantity + 1) * product.price } : item)));
    } else {
      setCart([...cart, { productId: product.id, productName: product.name, quantity: 1, unitPrice: product.price, subtotal: product.price, photoUrl: product.photoUrl }]);
    }
  };

  const removeFromCart = (productId: number) => {
    setCart(cart.filter((item) => item.productId !== productId));
  };

  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(
      cart.map((item) =>
        item.productId === productId
          ? { ...item, quantity, subtotal: quantity * item.unitPrice }
          : item
      )
    );
  };

  const handleAddItemsToComanda = () => {
    if (cart.length === 0) {
      toast.error("Adicione itens ao carrinho");
      return;
    }
    cart.forEach((item) => {
                      addItemToComanda.mutate({
                        comandaId: selectedComanda.id,
                        productId: item.productId,
                        quantity: item.quantity,
                      });
                    });
  };

  const handleCloseComanda = () => {
    closeComanda.mutate({ comandaId: selectedComanda.id });
  };

  const handleRemoveItem = (itemId: number) => {
    removeItemFromComanda.mutate({ itemId });
  };

  return (
    <div className="space-y-6 md:space-y-8 p-4 md:p-6">
      <div className="flex flex-col md:flex-row justify-between items-start gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900">Comandas</h1>
          <p className="text-gray-600 mt-2 text-sm md:text-base">Gerencie todas as suas comandas abertas</p>
        </div>
        <Dialog open={openNewComanda} onOpenChange={setOpenNewComanda}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700 w-full md:w-auto">
              <Plus className="w-4 h-4 mr-2" />
              Nova Comanda
            </Button>
          </DialogTrigger>
          <DialogContent className="w-[95vw] md:w-full">
            <DialogHeader>
              <DialogTitle>Abrir Nova Comanda</DialogTitle>
              <DialogDescription>Crie uma nova comanda para uma localização</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateComanda} className="space-y-4">
              <div>
                <Label htmlFor="location">Localização</Label>
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma localização" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations?.map((loc) => (
                      <SelectItem key={loc.id} value={loc.id.toString()}>
                        {loc.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="customerName">Nome do Cliente</Label>
                <Input
                  id="customerName"
                  placeholder="Ex: José da Quadra 4"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full bg-green-600 hover:bg-green-700">
                Criar Comanda
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tabs by Location */}
      <Tabs defaultValue={locations?.[0]?.id.toString()} className="w-full">
        <TabsList className="grid w-full gap-1 md:gap-2 overflow-x-auto" style={{ gridTemplateColumns: `repeat(auto-fit, minmax(80px, 1fr))` }}>
          {locations?.map((location) => (
            <TabsTrigger key={location.id} value={location.id.toString()} className="text-xs md:text-sm">
              {location.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {locations?.map((location) => (
          <TabsContent key={location.id} value={location.id.toString()} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
              {(comandas || [])
                .filter((c) => c.locationId === location.id && c.status === "aberta")
                .map((comanda) => (
                  <Card key={comanda.id} className="hover:shadow-lg transition-shadow flex flex-col">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base md:text-lg truncate">{comanda.customerName}</CardTitle>
                      <CardDescription className="text-xs md:text-sm">
                        Aberta em {new Date(comanda.createdAt).toLocaleTimeString("pt-BR")}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-2 md:space-y-3 flex-1 flex flex-col justify-between">
                      <div className="bg-gray-50 p-2 md:p-3 rounded-lg">
                        <p className="text-xs md:text-sm text-gray-600">Total</p>
                        <p className="text-xl md:text-2xl font-bold text-green-600">
                          R$ {((comanda.totalAmount || 0) / 100).toFixed(2)}
                        </p>
                      </div>

                      <Dialog open={openDetailsDialog && selectedComanda?.id === comanda.id} onOpenChange={setOpenDetailsDialog}>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            className="w-full text-xs md:text-sm"
                            onClick={() => handleViewDetails(comanda)}
                          >
                            <Eye className="w-3 h-3 md:w-4 md:h-4 mr-2" />
                            Detalhes
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="w-[95vw] md:max-w-2xl max-h-[90vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>Detalhes da Comanda - {selectedComanda?.customerName}</DialogTitle>
                            <DialogDescription>Gerencie itens e feche a comanda</DialogDescription>
                          </DialogHeader>

                          {selectedComanda && (
                            <div className="space-y-4">
                              {/* Current Items */}
                              <div>
                                <h3 className="font-bold mb-2">Itens da Comanda</h3>
                                <div className="space-y-2 max-h-48 overflow-y-auto">
                                  {selectedComanda.items?.map((item: any) => (
                                    <div key={item.id} className="flex justify-between items-center p-2 bg-gray-50 rounded border">
                                      <div className="flex-1 min-w-0">
                                        <p className="font-semibold text-sm truncate">{item.productName}</p>
                                        <p className="text-xs text-gray-600">
                                          {item.quantity}x R$ {(item.unitPrice / 100).toFixed(2)}
                                        </p>
                                      </div>
                                      <div className="text-right ml-2">
                                        <p className="font-bold text-sm">R$ {(item.subtotal / 100).toFixed(2)}</p>
                                        <Button
                                          size="sm"
                                          variant="ghost"
                                          className="p-0 h-6 w-6"
                                          onClick={() => handleRemoveItem(item.id)}
                                        >
                                          <X className="w-3 h-3 text-red-600" />
                                        </Button>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Add Items */}
                              <div className="border-t pt-4">
                                <h3 className="font-bold mb-2">Adicionar Itens</h3>
                                <div className="space-y-3">
                                  {categories?.map((category) => (
                                    <div key={category.id}>
                                      <p className="text-sm font-semibold text-gray-600 mb-2">{category.name}</p>
                                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                                        {products
                                          ?.filter((p) => p.categoryId === category.id)
                                          .map((product) => (
                                            <Card
                                              key={product.id}
                                              className="cursor-pointer hover:shadow-lg transition-shadow"
                                              onClick={() => addToCart(product)}
                                            >
                                              <CardContent className="p-2">
                                                {product.photoUrl && (
                                                  <img
                                                    src={product.photoUrl}
                                                    alt={product.name}
                                                    className="w-full h-12 md:h-16 object-cover rounded mb-1"
                                                  />
                                                )}
                                                <p className="font-semibold text-xs truncate">{product.name}</p>
                                                <p className="text-green-600 font-bold text-xs">R$ {(product.price / 100).toFixed(2)}</p>
                                              </CardContent>
                                            </Card>
                                          ))}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Cart */}
                              {cart.length > 0 && (
                                <div className="border-t pt-4">
                                  <h3 className="font-bold mb-2">Carrinho</h3>
                                  <div className="space-y-2 max-h-48 overflow-y-auto">
                                    {cart.map((item) => (
                                      <div key={item.productId} className="flex justify-between items-center p-2 bg-blue-50 rounded border border-blue-200">
                                        <div className="flex-1 min-w-0">
                                          <p className="font-semibold text-sm truncate">{item.productName}</p>
                                          <div className="flex items-center gap-1 mt-1">
                                            <Button
                                              size="sm"
                                              variant="outline"
                                              className="p-0 w-5 h-5"
                                              onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                            >
                                              <Minus className="w-2 h-2" />
                                            </Button>
                                            <span className="w-4 text-center text-xs font-bold">{item.quantity}</span>
                                            <Button
                                              size="sm"
                                              variant="outline"
                                              className="p-0 w-5 h-5"
                                              onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                                            >
                                              <Plus className="w-2 h-2" />
                                            </Button>
                                          </div>
                                        </div>
                                        <div className="text-right ml-2">
                                          <p className="font-bold text-sm">R$ {(item.subtotal / 100).toFixed(2)}</p>
                                          <Button
                                            size="sm"
                                            variant="ghost"
                                            className="p-0 h-6 w-6"
                                            onClick={() => removeFromCart(item.productId)}
                                          >
                                            <X className="w-3 h-3 text-red-600" />
                                          </Button>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                  <Button
                                    onClick={handleAddItemsToComanda}
                                    disabled={addItemToComanda.isPending}
                                    className="w-full mt-2 bg-blue-600 hover:bg-blue-700"
                                  >
                                    <Plus className="w-4 h-4 mr-2" />
                                    Adicionar {cart.length} Item(ns)
                                  </Button>
                                </div>
                              )}

                              {/* Close Button */}
                              <Button
                                onClick={handleCloseComanda}
                                disabled={closeComanda.isPending}
                                className="w-full bg-green-600 hover:bg-green-700"
                              >
                                <Check className="w-4 h-4 mr-2" />
                                Fechar Comanda
                              </Button>
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>

                      <Button
                        onClick={() => handleViewDetails(comanda)}
                        className="w-full bg-green-600 hover:bg-green-700 text-xs md:text-sm"
                      >
                        <Check className="w-3 h-3 md:w-4 md:h-4 mr-2" />
                        Fechar
                      </Button>
                    </CardContent>
                  </Card>
                ))}

              {!(comandas || []).some((c) => c.locationId === location.id && c.status === "aberta") && (
                <Card className="col-span-full">
                  <CardContent className="p-8 text-center">
                    <p className="text-gray-500 text-sm md:text-base">Nenhuma comanda aberta nesta localização</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      {/* Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base md:text-lg">Resumo de Comandas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
            <div className="bg-blue-50 p-3 md:p-4 rounded-lg">
              <p className="text-xs md:text-sm text-gray-600">Total de Comandas Abertas</p>
              <p className="text-2xl md:text-3xl font-bold text-blue-600">
                {(comandas || []).filter((c) => c.status === "aberta").length}
              </p>
            </div>
            <div className="bg-green-50 p-3 md:p-4 rounded-lg">
              <p className="text-xs md:text-sm text-gray-600">Faturamento em Comandas</p>
              <p className="text-2xl md:text-3xl font-bold text-green-600">
                R$ {((comandas || []).filter((c) => c.status === "aberta").reduce((sum, c) => sum + (c.totalAmount || 0), 0) / 100).toFixed(2)}
              </p>
            </div>
            <div className="bg-purple-50 p-3 md:p-4 rounded-lg">
              <p className="text-xs md:text-sm text-gray-600">Ticket Médio</p>
              <p className="text-2xl md:text-3xl font-bold text-purple-600">
                R${" "}
                {(comandas || []).filter((c) => c.status === "aberta").length
                  ? (
                      (
                        ((comandas || [])
                          .filter((c) => c.status === "aberta")
                          .reduce((sum, c) => sum + (c.totalAmount || 0), 0) /
                          (comandas || []).filter((c) => c.status === "aberta").length) /
                        100
                      ).toFixed(2)
                    )
                  : "0.00"}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
