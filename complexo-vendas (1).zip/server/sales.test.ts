import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// Mock context for authenticated user
function createAuthContext(): TrpcContext {
  const user: User = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "test",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("Sales System", () => {
  let ctx: TrpcContext;

  beforeAll(() => {
    ctx = createAuthContext();
  });

  describe("Categories", () => {
    it("should list categories", async () => {
      const caller = appRouter.createCaller(ctx);
      const categories = await caller.categories.list();
      expect(Array.isArray(categories)).toBe(true);
    });

    it("should create a new category", async () => {
      const caller = appRouter.createCaller(ctx);
      const result = await caller.categories.create({
        name: "Bebidas",
        description: "Bebidas diversas",
        color: "#FF0000",
      });
      expect(result).toBeDefined();
    });
  });

  describe("Products", () => {
    it("should list all products", async () => {
      const caller = appRouter.createCaller(ctx);
      const products = await caller.products.list();
      expect(Array.isArray(products)).toBe(true);
    });

    it("should create a new product", async () => {
      const caller = appRouter.createCaller(ctx);
      
      // First create a category
      const categoryResult = await caller.categories.create({
        name: "Comidas",
        description: "Comidas diversas",
        color: "#00FF00",
      });

      // Then create a product
      const productResult = await caller.products.create({
        categoryId: (categoryResult as any).insertId || 1,
        name: "Água 500ml",
        description: "Água mineral",
        price: 500, // R$ 5,00
        ean: "1234567890123",
        stock: 100,
      });

      expect(productResult).toBeDefined();
    });
  });

  describe("Locations", () => {
    it("should list all locations", async () => {
      const caller = appRouter.createCaller(ctx);
      const locations = await caller.locations.list();
      
      expect(Array.isArray(locations)).toBe(true);
      expect(locations.length).toBeGreaterThanOrEqual(8); // 7 quadras + 1 campo
      
      const quadras = locations.filter((l) => l.type === "quadra");
      const campos = locations.filter((l) => l.type === "campo");
      
      expect(quadras.length).toBe(7);
      expect(campos.length).toBe(1);
    });
  });

  describe("Comandas", () => {
    it("should list open comandas", async () => {
      const caller = appRouter.createCaller(ctx);
      const comandas = await caller.comandas.list();
      expect(Array.isArray(comandas)).toBe(true);
    });

    it("should create a new comanda", async () => {
      const caller = appRouter.createCaller(ctx);
      
      // Get first location
      const locations = await caller.locations.list();
      const firstLocation = locations[0];
      
      if (firstLocation) {
        const result = await caller.comandas.create({
          locationId: firstLocation.id,
          customerName: "José da Quadra 1",
        });
        
        expect(result).toBeDefined();
      }
    });
  });

  describe("Sales", () => {
    it("should get today's sales", async () => {
      const caller = appRouter.createCaller(ctx);
      const sales = await caller.sales.today();
      expect(Array.isArray(sales)).toBe(true);
    });
  });

  describe("Dashboard", () => {
    it("should get dashboard data for today", async () => {
      const caller = appRouter.createCaller(ctx);
      const dashboard = await caller.dashboard.today();
      
      expect(dashboard).toBeDefined();
      expect(dashboard.sales).toBeGreaterThanOrEqual(0);
      expect(dashboard.comandas).toBeGreaterThanOrEqual(0);
      expect(dashboard.totalRevenue).toBeGreaterThanOrEqual(0);
    });
  });

  describe("System", () => {
    it("should have auth logout working", async () => {
      const caller = appRouter.createCaller(ctx);
      const result = await caller.auth.logout();
      
      expect(result).toEqual({ success: true });
    });
  });
});
