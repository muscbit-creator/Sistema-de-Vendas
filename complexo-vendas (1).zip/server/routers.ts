import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import {
  getCategories,
  getCategoryById,
  getProducts,
  getProductsByCategory,
  getProductById,
  getLocations,
  getOpenComandas,
  getComandaById,
  getComandasByLocation,
  getSalesToday,
} from "./db";
import {
  categories,
  products,
  comandas,
  comandaItems,
  sales,
  saleItems,
  locations,
  stockMovements,
  type InsertCategory,
  type InsertProduct,
  type InsertComanda,
  type InsertComandaItem,
  type InsertSale,
  type InsertSaleItem,
  type InsertStockMovement,
} from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";
import { storagePut } from "./storage";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Categories Router
  categories: router({
    list: protectedProcedure.query(() => getCategories()),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => getCategoryById(input.id)),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1),
          description: z.string().optional(),
          color: z.string().default("#3B82F6"),
          icon: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const result = await db
          .insert(categories)
          .values(input as InsertCategory);
        return result;
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          color: z.string().optional(),
          icon: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const { id, ...data } = input;
        await db.update(categories).set(data).where(eq(categories.id, id));
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.delete(categories).where(eq(categories.id, input.id));
        return { success: true };
      }),
  }),

  // Products Router
  products: router({
    list: protectedProcedure.query(() => getProducts()),

    byCategory: protectedProcedure
      .input(z.object({ categoryId: z.number() }))
      .query(({ input }) => getProductsByCategory(input.categoryId)),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(({ input }) => getProductById(input.id)),

    create: protectedProcedure
      .input(
        z.object({
          categoryId: z.number(),
          name: z.string().min(1),
          description: z.string().optional(),
          price: z.number().int().positive(),
          ean: z.string().optional(),
          photoUrl: z.string().optional(),
          stock: z.number().int().default(0),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const result = await db
          .insert(products)
          .values(input as InsertProduct);
        return result;
      }),

    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          categoryId: z.number().optional(),
          name: z.string().optional(),
          description: z.string().optional(),
          price: z.number().int().optional(),
          ean: z.string().optional(),
          photoUrl: z.string().optional(),
          stock: z.number().int().optional(),
          active: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const { id, ...data } = input;
        await db.update(products).set(data).where(eq(products.id, id));
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db
          .update(products)
          .set({ active: 0 })
          .where(eq(products.id, input.id));
        return { success: true };
      }),

    uploadPhoto: protectedProcedure
      .input(
        z.object({
          file: z.instanceof(Buffer),
          filename: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        const fileKey = `products/${Date.now()}-${input.filename}`;
        const { url } = await storagePut(
          fileKey,
          input.file,
          "image/jpeg"
        );
        return { url };
      }),
  }),

  // Locations Router
  locations: router({
    list: protectedProcedure.query(() => getLocations()),
  }),

  // Comandas Router
  comandas: router({
    list: protectedProcedure.query(() => getOpenComandas()),

    byLocation: protectedProcedure
      .input(z.object({ locationId: z.number() }))
      .query(({ input }) => getComandasByLocation(input.locationId)),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return undefined;

        const comanda = await getComandaById(input.id);
        if (!comanda) return undefined;

        const items = await db
          .select()
          .from(comandaItems)
          .where(eq(comandaItems.comandaId, input.id));

        return { ...comanda, items };
      }),

    create: protectedProcedure
      .input(
        z.object({
          locationId: z.number(),
          customerName: z.string().min(1),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const result = await db
          .insert(comandas)
          .values(input as InsertComanda);
        return result;
      }),

    addItem: protectedProcedure
      .input(
        z.object({
          comandaId: z.number(),
          productId: z.number(),
          quantity: z.number().int().positive(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const product = await getProductById(input.productId);
        if (!product) throw new Error("Product not found");

        const subtotal = product.price * input.quantity;

        await db.insert(comandaItems).values({
          comandaId: input.comandaId,
          productId: input.productId,
          quantity: input.quantity,
          unitPrice: product.price,
          subtotal,
        } as InsertComandaItem);

        // Update comanda total
        const comanda = await getComandaById(input.comandaId);
        if (comanda) {
          const newTotal = (comanda.totalAmount || 0) + subtotal;
          await db
            .update(comandas)
            .set({ totalAmount: newTotal })
            .where(eq(comandas.id, input.comandaId));

          // Notify if comanda reaches high value
          if (newTotal > 50000) {
            // R$ 500
            await notifyOwner({
              title: "Comanda com valor alto",
              content: `Comanda de ${comanda.customerName} na ${comanda.locationId} atingiu R$ ${(newTotal / 100).toFixed(2)}`,
            });
          }
        }

        return { success: true };
      }),

    removeItem: protectedProcedure
      .input(z.object({ itemId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const item = await db
          .select()
          .from(comandaItems)
          .where(eq(comandaItems.id, input.itemId))
          .limit(1);

        if (item.length === 0) throw new Error("Item not found");

        const removedItem = item[0];
        await db
          .delete(comandaItems)
          .where(eq(comandaItems.id, input.itemId));

        // Update comanda total
        const comanda = await getComandaById(removedItem.comandaId);
        if (comanda) {
          const newTotal = Math.max(0, (comanda.totalAmount || 0) - removedItem.subtotal);
          await db
            .update(comandas)
            .set({ totalAmount: newTotal })
            .where(eq(comandas.id, removedItem.comandaId));
        }

        return { success: true };
      }),

    close: protectedProcedure
      .input(z.object({ comandaId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const comanda = await getComandaById(input.comandaId);
        if (!comanda) throw new Error("Comanda not found");

        await db
          .update(comandas)
          .set({ status: "fechada", closedAt: new Date() })
          .where(eq(comandas.id, input.comandaId));

        // Record stock movements
        const items = await db
          .select()
          .from(comandaItems)
          .where(eq(comandaItems.comandaId, input.comandaId));

        for (const item of items) {
          await db.insert(stockMovements).values({
            productId: item.productId,
            quantity: -item.quantity,
            type: "saida_comanda",
            reference: `comanda_${input.comandaId}`,
          } as InsertStockMovement);
        }

        return { success: true };
      }),
  }),

  // Sales Router (Vendas Diretas)
  sales: router({
    today: protectedProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];

      const todaySales = await getSalesToday();
      const salesWithItems = await Promise.all(
        todaySales.map(async (sale) => {
          const items = await db
            .select()
            .from(saleItems)
            .where(eq(saleItems.saleId, sale.id));
          return { ...sale, items };
        })
      );

      return salesWithItems;
    }),

    create: protectedProcedure
      .input(
        z.object({
          items: z.array(
            z.object({
              productId: z.number(),
              quantity: z.number().int().positive(),
            })
          ),
          paymentMethod: z.enum(["dinheiro", "cartao", "pix"]),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        let totalAmount = 0;
        const itemsData = [];

        for (const item of input.items) {
          const product = await getProductById(item.productId);
          if (!product) throw new Error(`Product ${item.productId} not found`);

          const subtotal = product.price * item.quantity;
          totalAmount += subtotal;

          itemsData.push({
            productId: item.productId,
            quantity: item.quantity,
            unitPrice: product.price,
            subtotal,
          });
        }

        // Create sale
        await db
          .insert(sales)
          .values({
            totalAmount,
            paymentMethod: input.paymentMethod,
          } as InsertSale);

        // Get the created sale ID by querying the most recent sale
        const createdSale = await db
          .select()
          .from(sales)
          .orderBy(desc(sales.id))
          .limit(1);
        
        const saleId = createdSale?.[0]?.id;
        if (!saleId) throw new Error("Failed to create sale: could not retrieve ID");

        // Add items
        for (const itemData of itemsData) {
          await db.insert(saleItems).values({
            saleId,
            productId: itemData.productId,
            quantity: itemData.quantity,
            unitPrice: itemData.unitPrice,
            subtotal: itemData.subtotal,
          } as InsertSaleItem);

          // Record stock movement
          await db.insert(stockMovements).values({
            productId: itemData.productId,
            quantity: -itemData.quantity,
            type: "saida_venda",
            reference: `sale_${saleId}`,
          } as InsertStockMovement);
        }

        // Notify owner of significant sales
        if (totalAmount > 100000) {
          // R$ 1000
          await notifyOwner({
            title: "Venda importante",
            content: `Venda de R$ ${(totalAmount / 100).toFixed(2)} realizada`,
          });
        }

        return { id: saleId, totalAmount };
      }),
  }),

  // Dashboard Router
  dashboard: router({
    today: protectedProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { sales: 0, comandas: 0, items: 0, totalRevenue: 0 };

      const todaySales = await getSalesToday();
      const totalSalesRevenue = todaySales.reduce(
        (sum, sale) => sum + sale.totalAmount,
        0
      );

      const openComandas = await getOpenComandas();
      const totalComandasRevenue = openComandas.reduce(
        (sum, comanda) => sum + (comanda.totalAmount || 0),
        0
      );

      const totalRevenue = totalSalesRevenue + totalComandasRevenue;

      return {
        sales: todaySales.length,
        comandas: openComandas.length,
        items: 0,
        totalRevenue,
      };
    }),
  }),

  // History Router
  history: router({
    sales: protectedProcedure
      .input(
        z.object({
          startDate: z.date().optional(),
          endDate: z.date().optional(),
        })
      )
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];

        const result = await db.select().from(sales);
        let filtered = result;

        if (input.startDate) {
          filtered = filtered.filter((s) => new Date(s.createdAt) >= input.startDate!);
        }
        if (input.endDate) {
          const endOfDay = new Date(input.endDate);
          endOfDay.setHours(23, 59, 59, 999);
          filtered = filtered.filter((s) => new Date(s.createdAt) <= endOfDay);
        }

        const salesWithItems = await Promise.all(
          filtered.map(async (sale) => {
            const items = await db
              .select({
                id: saleItems.id,
                quantity: saleItems.quantity,
                unitPrice: saleItems.unitPrice,
                subtotal: saleItems.subtotal,
                productName: products.name,
              })
              .from(saleItems)
              .leftJoin(products, eq(saleItems.productId, products.id))
              .where(eq(saleItems.saleId, sale.id));
            return { ...sale, items };
          })
        );

        return salesWithItems;
      }),

    comandas: protectedProcedure
      .input(
        z.object({
          startDate: z.date().optional(),
          endDate: z.date().optional(),
        })
      )
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];

        const result = await db
          .select()
          .from(comandas)
          .where(eq(comandas.status, "fechada"));
        let filtered = result;

        if (input.startDate) {
          filtered = filtered.filter((c) => c.closedAt && new Date(c.closedAt) >= input.startDate!);
        }
        if (input.endDate) {
          const endOfDay = new Date(input.endDate);
          endOfDay.setHours(23, 59, 59, 999);
          filtered = filtered.filter((c) => c.closedAt && new Date(c.closedAt) <= endOfDay);
        }

        const comandasWithItems = await Promise.all(
          filtered.map(async (comanda) => {
            const items = await db
              .select({
                id: comandaItems.id,
                quantity: comandaItems.quantity,
                unitPrice: comandaItems.unitPrice,
                subtotal: comandaItems.subtotal,
                productName: products.name,
              })
              .from(comandaItems)
              .leftJoin(products, eq(comandaItems.productId, products.id))
              .where(eq(comandaItems.comandaId, comanda.id));
            return { ...comanda, items };
          })
        );

        return comandasWithItems;
      }),
  }),
});

export type AppRouter = typeof appRouter;
